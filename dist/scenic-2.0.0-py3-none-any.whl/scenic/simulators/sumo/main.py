from scenic.simulators.sumo.interface import Interface as gui
from scenic.simulators.sumo.simulator import SumoSimulator as sim
from scenic.simulators.sumo.Utilities.config import SUMO

'''sim("C:\\Users\\crump\\OneDrive\\Documents\\GitHub\\Scenic-Sumo\\Map\\TwoWayJunction\\TwoWayJunction.sumocfg",
    "C:\\Users\\crump\\OneDrive\\Documents\\GitHub\\Scenic-Sumo\\Scenarios\\TwoWayJunction.scenic",
    SUMO)'''
gui()
