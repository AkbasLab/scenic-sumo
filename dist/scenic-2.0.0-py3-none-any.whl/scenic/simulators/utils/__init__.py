"""Various utilities useful across multiple simulators.

.. raw:: html

   <h2>Submodules</h2>

.. autosummary::
   :toctree:

   colors
"""
