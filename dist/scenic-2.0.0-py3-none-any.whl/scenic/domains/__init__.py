"""General scenario domains used across simulators.

.. raw:: html

   <h2>Submodules</h2>

.. autosummary::
   :toctree:

   driving
"""
